function externalAlert(){
    alert('External Alert');
}
function externalConfirm(){
   if(confirm('Are You Human....')){
       alert('Yes')
   }
   else{
       alert('No')
   }
}
function externalPrompt(){
    var fname=prompt('Enter Your First Name');
    var lname=prompt('Enter Your Last Name');
    alert(fname+" "+lname)
}