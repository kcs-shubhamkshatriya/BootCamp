﻿namespace test
{
    internal class EncapsulationAndInheritanceDemo
    {
        public int i { get; internal set; }
        public int pi { get; internal set; }
        public int pu { get; internal set; }
    }
}