﻿using System;

namespace test
{
    struct strucref
    {
        public int a;
    }
    public class Encapsulation
    {
        private int pr; 
        internal int i; 
        protected int prot;
        public int pu;
        protected internal int pi;
        private protected int pp;

        
        public Encapsulation()
        {
            pr = 100;   
        }

        class EncapsulationAndInheritanceDemo : Encapsulation
        {
            public void AccessibleDemoFunOfDirectChildClass()
            {
                i = 20; 
                prot = 30; 
                pi = 40;
                pp = 60;
            }
        }
        public void AccessibleDemoFun()
        {
            pr = 10; 
            i = 20; 
            prot = 30; 
            pi = 40; 
            pp = 50;
        }
    }
    internal class Program
    {
        public static object En { get; private set; }

        static void Main(string[] args)
        {
            Program program1 = new Program();
            Console.WriteLine("Hello World!");
            strucref strucref1 = new strucref();
            strucref strucref2 = new strucref();

            strucref1.a = 10;
            strucref2.a = 20;

            Console.WriteLine(strucref1.a);
            Console.WriteLine(strucref2.a);


            Encapsulation en = new Encapsulation();
            en.i = 10;
            en.pi = 20;
            en.pu = 30;

            Console.WriteLine(en.pu);
            Console.WriteLine(en.i);
            Console.WriteLine(en.pi);

            EncapsulationAndInheritanceDemo EnI = new EncapsulationAndInheritanceDemo();
            EnI.i = 100; 
            EnI.pi = 101; 
            EnI.pu = 102;


            Console.WriteLine(EnI.i);
            Console.WriteLine(EnI.pi);
            Console.WriteLine(EnI.pu);

        }

    }
}
